<?php

namespace Plugin\Controller;

class PublicController
{

}
