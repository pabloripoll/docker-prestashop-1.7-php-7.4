<?php

namespace PrCustom\Controller;

use PrCustom\Support\Log;
use Plugin\Controller\Controller;

/**
 * Provides the settings and admin page
 */
class AdminBackController extends Controller
{

}