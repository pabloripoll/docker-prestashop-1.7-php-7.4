<?= $this->private(); ?>

<?= $this->view('admin._common.nav.example') ?>

<h6 class="text-center">Section <b>Dashboard</b>: content...</h6>