<?= $this->private(); ?>

<?= $this->view('admin._common.nav.setting') ?>

<h6 class="text-center">Section <b>External</b>: content...</h6>
